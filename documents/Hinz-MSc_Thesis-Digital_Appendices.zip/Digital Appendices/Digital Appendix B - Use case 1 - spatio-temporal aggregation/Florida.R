library(xts)
library(sp)
library(spacetime)
library(maps)
library(maptools)
library(SpatialSemantics)
library(Rgraphviz)

## Data preparation
## download "ECDovelatlon.dat" and ECDoveBBS1986_2003.dat

#read and prepare observation locations as spatial points:
ecd.locations <- as.matrix(read.table("ECDovelatlon.dat", header = FALSE))
ecd.locations <- SpatialPoints(ecd.locations[,c(2,1)])
proj4string(ecd.locations) <- CRS("+proj=longlat +datum=WGS84")
#observation years (1986-2003):
ecd.years <- as.Date(paste0(1986:2003, "-01-01"), "%Y-%m-%d")
#read and prepare bird count data as single-column data frame:
ecd <- read.table("ECDoveBBS1986_2003.dat", header=FALSE)
ecd[ecd == -1] <- NA
ecd.data = data.frame(counts = as.vector(as.matrix(ecd)))
#retrieve Florida state boundaries:
m <- map("state", "florida", fill = TRUE, plot = FALSE)
FL <- map2SpatialPolygons(m, "FL")
proj4string(FL) <- proj4string(ecd.locations)

#plot location observations near Florida
plot(FL)
points(ecd.locations, pch="+", col="red")

## Prepare semantics

# Create function wrapper for STFDF constructur
postprocessor = function(args, output, semantics){
  functionalType(output, parent = FALSE) <- "MarkedEvent"
  return(output)
}
STFDF.MarkedEvent = STFDF #give constructor a more informative name
captureSemantics(STFDF.MarkedEvent, postprocessor = postprocessor) <- TRUE
# Create manual wrapper function arround aggregate (direct wrapping currently not supported)
aggregate.st <- function(x, by, FUN, na.rm){
  output = aggregate(x, by, FUN, na.rm = na.rm)
  functionalType(output) <- "TLattice"
  return(output)
}
#encapsulate intervall-subsetting as a semantic function
getTimeIntervals = function(T_set, breaks){
  output = T_set[breaks]
  attr(output, "semantics") <- "I set"
  return(output)
}
#encapsulate STF-constructor in a function that preserves semantics
STF.sem = function(sp, time){
  output = STF(sp, time) #sp semantics are preserved already
  attr(output@time, "semantics") <- attr(time, "semantics")
  return(output)
}

#Analysis starts here:
enableProvenance()
  #Create space-time object of all bird counts
  ecd.st <- STFDF.MarkedEvent(ecd.locations, ecd.years, ecd.data)
  #Create target-geometry to aggregate over Florida-state area
  # in 2-year periods
  target.years = getTimeIntervals(ecd.years, c(4,6,8,10,12))
  target.st <- STF.sem(FL, target.years)
  #execute aggregation
  ts = aggregate.st(ecd.st, target.st, sum, na.rm = TRUE)
disableProvenance()

#plot and export derivatin graph
g = getScriptGraph()
plot(g)
toFile(g, layoutType="dot", filename="Florida.dot", fileType="dot")
system(command = "dot -Tpdf Florida.dot -o Florida.pdf")
#query semantics
getSemanticPedigree(ecd.st)
getSemanticPedigree(ts)
getSemanticPedigree(target.st)
#rset provenance to its default state
reset_provenance()
