library(xts)
library(sp)
library(spacetime)
library(maps)
library(maptools)
library(SpatialSemantics)
library(Rgraphviz)

## Data preparation

#read and prepare observation locations as spatial points:
ecd.locations <- as.matrix(read.table("ECDovelatlon.dat", header = FALSE))
ecd.locations <- SpatialPoints(ecd.locations[,c(2,1)])
proj4string(ecd.locations) <- CRS("+proj=longlat +datum=WGS84")
# observation years (1986-2003):
ecd.years <- as.Date(paste0(1986:2003, "-01-01"), "%Y-%m-%d")
#read and prepare bird count data as single-column data frame:
ecd <- read.table("ECDoveBBS1986_2003.dat", header=FALSE)
ecd[ecd == -1] <- NA
ecd.data = data.frame(counts = as.vector(as.matrix(ecd)))
#retrieve florida state boundaries:
m <- map("state", "florida", fill = TRUE, plot = FALSE)
FL <- map2SpatialPolygons(m, "FL")
proj4string(FL) <- proj4string(ecd.locations)

#plot breed locations near Florida
plot(FL)
points(ecd.locations, pch="+", col="red")

#Analysis starts here:
enableProvenance()
  #Create space-time object of all bird counts
  ecd.st <- STFDF(ecd.locations, ecd.years, ecd.data)
  #Create target-geometry to aggregate over Florida-state area
  # in 2-year periods
  target.years = ecd.years[c(4,6,8,10,12)]
  target.st <- STF(FL, target.years)
  #execute aggregation
  ts = aggregate(ecd.st, target.st, sum, na.rm = TRUE)
disableProvenance()

g = getScriptGraph()
plot(g)
toFile(g, layoutType="dot", filename="Florida-noAnnotations.dot", fileType="dot")
system(command = "dot -Tpdf Florida-noAnnotations.dot -o Florida-noAnnotations.pdf")

reset_provenance()
