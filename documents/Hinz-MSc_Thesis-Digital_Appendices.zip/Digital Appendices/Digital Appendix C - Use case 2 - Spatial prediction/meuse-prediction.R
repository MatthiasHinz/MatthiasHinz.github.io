library(mss)
library(sp)
library(gstat)
library(Rgraphviz)
library(SpatialSemantics)

# define helper functions
#---------------------------------------------------
init_model = function(pointData) {
  range = sqrt(sum(apply(bbox(pointData@observations), 1, diff)^2)) / 6
  sill = var(pointData[[1]])
  vgm(2 * sill / 3, "Sph", range, sill / 3) # initial variogram model
}
captureSemantics(init_model) <-TRUE

modelSemivariogram = function(pointData) {
  n = names(pointData@observations)
  if (length(n) > 1)
    warning("taking first attribute variable")
  f = as.formula(paste(n[1], "~1")) # which variable to model? take first.
  init = init_model(pointData)
  fit.variogram(variogram(f, pointData@observations), init)
}
captureSemantics(modelSemivariogram) <-TRUE

getInterpolator = function(params, pointData) {
  if (!is(params, "variogramModel"))
    warning("getInterpolator: params should be of class variogramModel")
  out=function(locOfInterest) {
    n = names(pointData@observations)[1] #take first variogram model
    f = as.formula(paste(n, "~ 1"))
    out=interpolate(f, pointData, locOfInterest, model = params)
    functionalType(out@observations) <- "SField"
    return(out)
  }
  captureSemantics(out, semantics = "S -> (S, Q)") <-TRUE
  attr(out, "semantics") <- "(S -> (S x Q))"
  return(out)
}
captureSemantics(getInterpolator, procedureName="getInterpolator") <-TRUE
captureSemantics(geometry, procedureName="fst") <- TRUE
SFieldData <- SField #rename constructor to avoid ambiguities
captureSemantics(SFieldData,  procedureName = "SFieldData",
  postprocessor = function(args, output, call_semantics) {
    attr(output@observations, "semanticPedigree") <- getSemanticPedigree(args$observations)
    attr(output@observations, "semantics") <- attr(args$observations,"semantics")
    return(output)
  }
) <- TRUE

enableProvenance() # Run analysis
# load meuse data from package sp in current session:
demo(meuse, ask=FALSE, echo=FALSE)
functionalType(meuse) <- "SField"
functionalType(meuse.grid) <- "SField"
meuse$lzinc = log(meuse$zinc)
zincPointData = SFieldData(meuse["lzinc"], meuse.area)
interpolator = getInterpolator(modelSemivariogram(zincPointData), zincPointData)
locInterest = SFieldData(geometry(meuse.grid), geometry(meuse.grid), cellsArePoints = TRUE)
intZincPointData = interpolator(locInterest, semantics = "S set -> S x Q set")
disableProvenance() #end of analysis
spplot(intZincPointData@observations["var1.pred"])
plot(zincPointData) #plot data

# Export / visualize derivation graph
g = getScriptGraph()
plot(g, main="Derivation Graph")
toFile(g , layoutType="dot", filename="meuse-prediction.dot", fileType="dot")
system(command = "dot -Tpdf meuse-prediction.dot -o meuse-prediction.pdf")

reset_provenance()
