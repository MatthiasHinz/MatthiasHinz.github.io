library(SPODT)
library(tree)
library(SpatialSemantics)
library(Rgraphviz)
#prepare semantics and wrappers
validator = function(args, output, semantics, assumtions){
  data = args[["data"]]
  pedigreeData = getSemanticPedigree(data)
  valid = "SMarkedEvent" %in% pedigreeData$procedureName
  if(!valid){
    message= "Spatial partitioning with the given input data was not intended.\nExpected were SMarkedEventData, "
    if(is.null(functionalType(data)))
      message = paste0("but functional type of data is unknown.")
      else
    message = paste0(message, "but given were ",functionalType(data),"Data.")
    warning(message)
  }
  return(valid)
}
spodt.malaria <- function(params, data){
  args = append(params, list(data=data))
  output = base::do.call(SPODT::spodt, args)
  attr(output, "semantics") <-"SInvField"
  return(output)
}
captureSemantics(spodt.malaria, validator=validator) <- TRUE
postprocessor = function(args, output, semantics){
  functionalType(output, parent=FALSE) <- "SInvField"
  return(output)
}
captureSemantics(spodtSpatialLines, postprocessor=postprocessor) <- TRUE

#data preparation
data("dataMALARIA")
coordinates(dataMALARIA) <- c("x", "y")
proj4string(dataMALARIA) <- "+proj=longlat +datum=WGS84 +ellps=WGS84"
dataMALARIA <- spTransform(dataMALARIA, CRS("+proj=merc +datum=WGS84 +ellps=WGS84"))
functionalType(dataMALARIA) <- "SMarkedEvent"

enableProvenance()# start recording provenance
params = list(formula = z ~1, graft = 0.13, level.max = 7, min.parent = 25, min.child = 2, rtwo.min = 0.01)
spodt.results <- spodt.malaria(params = params, dataMALARIA)
#create spatial lines that divide the study area into regions of higher / lower malaria risk
SSL.result <- spodtSpatialLines(spodt.results, dataMALARIA)
disableProvenance()

##PLOT RESULTS
#classification tree
spodt.tree(spodt.results)
plot(SSL.result)
#adding each location
points(dataMALARIA, cex = log(dataMALARIA@data$z*10))
### END OF ANALSIS

#visualize / export derivation graph
g = getScriptGraph()
plot(g, main="Derivation Graph")
toFile(g , layoutType="dot", filename="SPODT-use-case.dot", fileType="dot")
system(command = "dot -Tpdf SPODT-use-case.dot -o SPODT-use-case.pdf")

#delete internal provenance record
reset_provenance()

#test validator against meuse data set
library(sp)
demo(meuse,echo = FALSE, ask = FALSE)
functionalType(meuse) <- "SField"
params = list(formula = zinc ~1, graft = 0.13, level.max = 7, min.parent = 25, min.child = 2, rtwo.min = 0.01)
meuse.results = spodt.malaria(params,meuse)



